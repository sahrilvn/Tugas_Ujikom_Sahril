<!DOCTYPE html>
<html>
<head>
	<title>Data Pembayaran SPP | SPP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Admin/Pembayaran_SPP/Data_Pembayaran_SPP.css') ?>">
</head>
<body>
	<br><br><br><br>

	<div class="content-home">
	<h4 style="color: #c2c3c4;text-align: center;margin-top: 150px; ">Selamat datang di aplikasi IURAN ONLINE SMK</h4>
	</div>
	<br><br><br>
</body>
</html>
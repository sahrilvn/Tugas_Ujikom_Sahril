<!DOCTYPE html>
<html>
<head>
	<title>Hasil</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Admin/Pembayaran_SPP/SPP_Selesai.css') ?>">
</head>
<body>
	<br><br><br><br>

	<div class="content-home">
		<p>Siswa dengan NIS tersebut sudah membayar seluruh SPP</p>
	</div>

	<br><br><br>
</body>
</html>
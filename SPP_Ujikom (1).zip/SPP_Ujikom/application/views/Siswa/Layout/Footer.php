<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Siswa/Layout/Footer.css') ?>">
</head>
<body>
	<footer>
		<div class="container">
			<p>
				SMK NEGERI 2 SUKABUMI
			</p>
		</div>
	</footer>
</body>
</html>
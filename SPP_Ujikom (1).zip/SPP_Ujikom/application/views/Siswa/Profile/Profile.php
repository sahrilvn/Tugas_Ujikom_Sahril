<!DOCTYPE html>
<html>
<head>
	<title>Profile | SPP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Siswa/Account/Profile.css') ?>">
</head>
<body>
	<br><br><br><br>

	<center>
		<div class="container col-md-8">
			<div class="card">
				<h5 class="card-header">DATA SISWA</h5>
				
				<div class="container" style="text-align: left;"><br>
					<div class="row">
						<div class="col">
							<p>NISN</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col">
							<p class="card-text"><?php echo $profile->nisn; ?></p>
						</div>
					</div>
					
					<div class="row">
						<div class="col">
							<p>NIS</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col">
							<p class="card-text"><?php echo $profile->nis; ?></p>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<p>Nama Lengkap</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col">
							<p class="card-text"><?php echo $profile->nama; ?></p>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<p>Kelas</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col">
							<p class="card-text"><?php echo $profile->nama_kelas.' '.$profile->kompetensi_keahlian; ?></p>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<p>Nomor Telepon</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col">
							<p class="card-text"><?php echo $profile->no_telp; ?></p>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<p>Alamat</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col">
							<p class="card-text"><?php echo $profile->alamat ?></p>
						</div>
					</div>
				</div>
			</div>
			<br>
			<a href="<?php echo site_url('Siswa/Ubah_Password') ?>" class="btn btn-primary">Ubah Password</a>
			<a href="<?php echo site_url('Siswa/Data_Pembayaran') ?>" class="btn btn-warning">Lihat Data Pembayaran</a>

		</div>
	</center>

	<br><br><br><br><br>
</body>
</html>
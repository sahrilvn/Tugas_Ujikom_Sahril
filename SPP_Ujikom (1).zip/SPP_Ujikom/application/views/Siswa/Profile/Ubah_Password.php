<!DOCTYPE html>
<html>
<head>
	<title>Ubah Password | SPP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Siswa/Account/Ubah_Password.css') ?>">
</head>
<body>
	<br><br><br><br>

	<center>
		<div class="container col-md-6">
		<div class="card">
			<h5 class="card-header">UBAH PASSWORD</h5><br>
			<form method="post" action="<?php echo site_url('Siswa/Proses_Ubah_Password') ?>" class="form-group col-md-12">
				<div class="container" style="text-align: left;"><br>
				<div class="row">
						<div class="col">
							<p>Password Lama</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col-md-8">
							<p class="card-text"><input type="password" name="pass_lama" required="" placeholder="Masukan Password Lama..." class="form-control"></p>
						</div>
						<br><br><br>
						<div class="col">
							<p>Password Baru</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col-md-8">
							<p class="card-text"><input type="password" name="pass_baru" required="" placeholder="Masukan Password Baru..." class="form-control"></p>
						</div>
						<br><br><br>
						<div class="col">
							<p>Konfirmasi Password</p>
						</div>
						<div class="col" style="max-width: 5px;">
							:
						</div>
						<div class="col-md-8">
							<p class="card-text"><input type="password" name="pass_baru2" required="" placeholder="Masukan Password Baru..." class="form-control"></p>
						</div>
				</div>
				<button class="btn btn-info">Simpan</button>
				</div>
			</form>
		</div>
		</div>
	</center>

	<br><br><br><br><br>
</body>
</html>
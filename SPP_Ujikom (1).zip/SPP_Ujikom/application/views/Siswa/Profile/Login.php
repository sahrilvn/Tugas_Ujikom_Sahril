<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Siswa/Account/Login.css') ?>">

	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/bootstrap/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/bootstrap/js/bootstrap.min.js') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/bootstrap/js/jquery-3.2.1.js') ?>">
</head>
<body>
	<center>
	<div class="card" id="card-login">
		<form method="post" action="<?php echo site_url('Siswa/Proses_Login') ?>" class="form-group">
			<div>
				<h4 style="padding: 40px 0 30px 0;">LOGIN SISWA</h4>
			</div>
			<div class="container">
				<div class="card-text col-md-11">
					<input type="text" name="nis" placeholder="Masukan NIS..." required="" class="form-control"><br>
					<input type="password" name="password" placeholder="Masukan Password..." required="" class="form-control"><br>
					<button class="btn btn-info" style="width: 100%;">Login</button>
				</div>
			</div>
		</form>
	</div>
	</center>
</body>
</html>
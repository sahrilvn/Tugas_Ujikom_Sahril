<!DOCTYPE html>
<html>
<head>
	<title>Data Pembayaran | SPP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Siswa/Home.css') ?>">
</head>
<body>
	<br><br>

	<center>
	<?php $bulan 	= array('Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'); ?>
			<div class="row-col-md-6">
				<div class="col-md-6"><br>
					<center><h6>DATA PEMBAYARAN</h6></center><br>

					<div class="container">
					<?php  
						for ($i=0; $i < 12; $i++) { 
							$cek1 = count($spp_tahun1[$i]);
							if($cek1 > 0){ ?>

						<div class="row" style="width: 100%;border-radius: 2px;border: 1px solid rgba(2,2,2,.1);color: #333;background: rgba(200,200,200,.1);margin-bottom: 5px;padding-top: 10px;">
							<div class="col">
								<p style="text-align: left;"><?php echo $bulan[$i]; ?></p>
							</div>
							<div class="col">
								<small>Rp.<?php echo $spp_tahun1[$i]->jumlah_bayar; ?>;</small>
							</div>
							<div class="col">
								<p><i class="fa fa-check" style="color: green;font-size: 25px;"></i></p>
							</div>
						</div>
								
					<?php	}else{ ?>

						<div class="row" style="width: 100%;border-radius: 2px;border: 1px solid rgba(2,2,2,.1);color: #333;margin-bottom: 5px;padding-top: 10px;">
							<div class="col">
								<p style="text-align: left;"><?php echo $bulan[$i]; ?></p>
							</div>
							<div class="col" style="text-align: right;">
								<small>Belum</small>
							</div>
						</div>

					<?php	}
						}
					?>
					</div>
					<br><br>
				</div>
				
		</div>

	</center>

	<br><br><br><br>
</body>
</html>
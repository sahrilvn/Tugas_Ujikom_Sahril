<!DOCTYPE html>
<html>
<head>
	<title>Profile | SPP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Profile/Profile_petugas.css') ?>">
</head>
<body>
	<br><br><br><br>

	<div class="content-home">
		<form method="post" action="<?php echo site_url('Admin/Proses_Ubah_Password') ?>" class="form-group col-md-8">
					<div class="card">
			<h5 class="card-header">Ubah Password</h5>
				
			<div class="container" style="text-align: left;"><br>
				<div class="row">
					<div class="col">
						<p>Password Lama</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<input type="password" name="pass_lama" required="" placeholder="Masukan Password Lama..." class="form-control"><br>
					</div>
				</div>
			<div class="row">
					<div class="col">
						<p>Password Baru</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<input type="password" name="pass_baru" required="" placeholder="Masukan Password Baru..." class="form-control"><br>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<p>Konfirmasi Password</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<input type="password" name="pass_baru2" required="" placeholder="Masukan Ulang Password Baru..." class="form-control"><br>
					</div>
				</div>
			<button class="btn btn-sm btn-info">Simpan</button>
		</form>
	</div>

	<br><br>
		
</body>
</html>
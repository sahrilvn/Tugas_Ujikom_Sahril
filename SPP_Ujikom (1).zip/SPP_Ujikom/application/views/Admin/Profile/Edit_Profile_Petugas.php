<!DOCTYPE html>
<html>
<head>
	<title>Profile | SPP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Profile/Edit_Profile_Petugas.css') ?>">
</head>
<body>
	<br><br><br><br>

	<div class="content-home">
		<form method="post" action="<?php echo site_url('Admin/Proses_Edit_Profile_Petugas/'.$edit->id_petugas) ?>" class="form-group col-md-8">
		<div class="card">
			<h5 class="card-header">Edit Profil</h5>
				
			<div class="container" style="text-align: left;"><br>
				<div class="row">
					<div class="col">
						<p>Nama Petugas</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<input type="text" name="nama" required="" placeholder="Nama Petugas..." value="<?php echo $edit->nama_petugas ?>" class="form-control"><br>
					</div>
				</div>
			<div class="row">
					<div class="col">
						<p>Username</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<input type="text" name="username" required="" placeholder="Username..." value="<?php echo $edit->username ?>" class="form-control"><br>
					</div>
				</div>
			<button class="btn btn-sm btn-info">Simpan</button>
		</form>
	</div>

	<br><br>
</body>
</html>
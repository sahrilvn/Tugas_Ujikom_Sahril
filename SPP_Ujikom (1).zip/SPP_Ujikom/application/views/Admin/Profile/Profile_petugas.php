<!DOCTYPE html>
<html>
<head>
	<title>Profile | SPP</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Profile/Profile_petugas.css') ?>">
</head>
<body>
	<br><br><br><br>

	<div class="content-home">

		<div class="card">
			<h5 class="card-header">Profil</h5>
				
			<div class="container" style="text-align: left;"><br>
				<div class="row">
					<div class="col">
						<p>Nama Petugas</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<p class="card-text"><?php echo $profile->nama_petugas; ?></p>
					</div>
				</div>
					
				<div class="row">
					<div class="col">
						<p>Username</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<p class="card-text"><?php echo $profile->username; ?></p>
					</div>
				</div>

				<div class="row">
					<div class="col">
						<p>Level</p>
					</div>
					<div class="col" style="max-width: 5px;">
						:
					</div>
					<div class="col">
						<p class="card-text"><?php echo $profile->level; ?></p>
					</div>
				</div>

				<br>

				<a href="<?php echo site_url('Admin/Edit_Profile') ?>" class="btn btn-sm btn-info">Edit Profile</a>&nbsp;&nbsp;
				<a href="<?php echo site_url('Admin/Ubah_Password') ?>" class="btn btn-sm btn-success">Ubah Password</a>

				<br><br>

			</div>
		</div>
	</div>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/bootstrap/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/bootstrap/js/bootstrap.min.js') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/bootstrap/js/jquery-3.2.1.js') ?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('./assets/css/Layout_admin/Footer.css') ?>">
</head>
<body>
	<footer>
		<center>
			<div class="container">
				<p id="text-footer">Copyright&copy;SPPSMEA2020</p>
			</div>
		</center>
	</footer>
</body>
</html>